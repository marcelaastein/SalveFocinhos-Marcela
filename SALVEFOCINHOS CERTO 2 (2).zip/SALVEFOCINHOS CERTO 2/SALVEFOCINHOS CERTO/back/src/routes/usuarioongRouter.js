const { Router } = require('express');
const { storeOng } = require('../controller/usuarioongController');

const router = Router();

router.post('/store/ong', storeOng);

module.exports = router;
